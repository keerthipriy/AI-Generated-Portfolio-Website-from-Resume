
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Simple animation trigger on scroll (optional, for more complex animations)
    const animatedElements = document.querySelectorAll('.glassmorphism, .skill-card, .project-card, .cert-card');

    const observerOptions = {
        root: null,
        threshold: 0.1,
        rootMargin: '0px'
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                // Optional: Disconnect observer after an element becomes visible if it's a one-time animation
                // observer.unobserve(entry.target);
            } else {
                 // Optional: Remove class if you want elements to re-animate when they leave viewport
                 // entry.target.classList.remove('is-visible');
            }
        });
    }, observerOptions);

    animatedElements.forEach(el => {
        // Add a default hidden state for elements to be animated
        el.classList.add('fade-in');
        observer.observe(el);
    });

    // Add a CSS class when an element becomes visible
    // This requires corresponding CSS rules for '.is-visible' to show the element
    // Example CSS:
    // .fade-in { opacity: 0; transform: translateY(20px); transition: opacity 0.6s ease-out, transform 0.6s ease-out; }
    // .is-visible { opacity: 1; transform: translateY(0); }

    // For the current implementation, the CSS animations are handled directly by `:hover` and keyframes.
    // If you want scroll-triggered animations, uncomment the observer part and add `.fade-in` and `.is-visible` CSS.
});
</script>
